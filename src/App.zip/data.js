

 export const Data=[
    {
        image:require('../src/assets/images/feature-1.jpg'),
        name:"Guaranteed PURE",
        text:"All Grace formulations adhere to strict purity standards and will never contain harsh or toxicingredients"
    },
    {
       image:require('../src/assets/images/feature-2.jpg'),
       name:"Completely Cruelty-Free" ,
        text:"All Grace formulations adhere to strict purity standards and will never contain"
    },
    {
        image:require('../src/assets/images/feature-3.jpg'),
        name:"Computer Science",
        text:"All Grace formulations adhere to strict purity standards and will never contain"
    }
]


  export const shopData=[
     {
         image:require('./assets/images/product-01.jpg'),
         price:"$39.00",
         span:"$29.00",
         title:"Facial cleanser",
         text:"5170 reviews"
     },

     {
         image:require('./assets/images/product-02.jpg'),
         price:"$39.00",
         span:"$29.00",
         title:"Facial cleanser",
         text:"5170 reviews"
     },

     {
         image:require('./assets/images/product-03.jpg'),
         price:"$39.00",
         span:"$29.00",
         title:"Facial cleanser",
         text:"5170 reviews"
     },

     {
         image:require('./assets/images/product-04.jpg'),
         price:"$39.00",
         span:"$29.00",
         title:"Facial cleanser",
         text:"5170 reviews"
     },
     {
         image:require('./assets/images/product-05.jpg'),
         price:"$39.00",
         span:"$29.00",
         title:"Facial cleanser",
         text:"5170 reviews"
     },

 ]

  export const Photo = [
     {
         image:require('./assets/images/collection-1.jpg'),
         name:"Summer Collection",
         p:"Starting at $17.99",
         text:"Shop Now",

     },

     {
         image:require('./assets/images/collection-2.jpg'),
         name:"What’s New?",
         p:"Get the glow",
         text:"Get the glow"
     },
     {
         image:require('./assets/images/collection-3.jpg'),
         name: "Buy 1 Get 1",
         p:"Starting at $7.99",
         text:"Discover Now"

     }
 ]

  export const shopData2 =
     [
         {
             image: require('./assets/images/product-07.jpg'),
             price: "$39.00",
             span: "$29.00",
             title: "Facial cleanser",
             text: "5170 reviews"
         },
         {
             image: require('./assets/images/product-08.jpg'),
             price: "$39.00",
             span: "$29.00",
             title: "Facial cleanser",
             text: "5170 reviews"
         },

         {
             image: require('./assets/images/product-09.jpg'),
             price: "$39.00",
             span: "$29.00",
             title: "Facial cleanser",
             text: "5170 reviews"
         },

         {
             image: require('./assets/images/product-09.jpg'),
             price: "$39.00",
             span: "$29.00",
             title: "Facial cleanser",
             text: "5170 reviews"
         },

         {
             image: require('./assets/images/product-10.jpg'),
             price: "$39.00",
             span: "$29.00",
             title: "Facial cleanser",
             text: "5170 reviews"
         },
     ]
