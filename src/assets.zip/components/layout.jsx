import React from 'react';
import Header from "../navBar/Header";
import Footer from "../navBar/Footer";

import {Outlet} from "react-router-dom";

import Offer from "../navBar/Offer";
import {Home} from "../navBar/header/home";
import Blog from "../Mobile/Blog";

function Layout(props) {
    return (
        <div>
            <Header />

            <Outlet/>
            <Blog />
            {/*<Offer />*/}
            {/*<Footer/>*/}

        </div>
    );
}

export default Layout;