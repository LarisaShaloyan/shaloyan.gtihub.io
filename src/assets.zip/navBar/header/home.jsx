import React from 'react';

 export  function Home(props) {
     return (
         <div>

             <nav className="navbar">
                 <a href="#home" className="navbar-link has-after">Home</a>

             </nav>


         </div>
     );
 }