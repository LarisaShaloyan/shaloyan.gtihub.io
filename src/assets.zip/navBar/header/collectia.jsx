import React from 'react';

export  function Collectia(props) {
    return (
        <div>

            <nav className="navbar">
                <ul className="navbar-list">

                    <li>
                        <a href="#collectia" className="navbar-link has-after">collection</a>
                    </li>


                </ul>
            </nav>


        </div>
    );
}